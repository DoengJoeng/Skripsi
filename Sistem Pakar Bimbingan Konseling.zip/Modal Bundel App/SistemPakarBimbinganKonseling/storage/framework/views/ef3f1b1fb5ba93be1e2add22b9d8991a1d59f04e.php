<?php $__env->startSection('content'); ?>
   <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col">
            <div class="card card-primary card-outline">
              <div class="card-body box-profile">
                <div class="text-center"><p><strong>Detail Data permasalahan</strong></p>
                </div>
                <ul class="list-group list-group-unbordered mb-3">
                  <li class="list-group-item">
                    <b>Keterangan permasalahan</b> <a class="float-right"><?php echo e($permasalahan->keteranganPermasalahan); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Keterangan Solusi</b> <a class="float-right"><?php echo e($permasalahan->solusi); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Created at :</b> <a class="float-right"><?php echo e($permasalahan->created_at->format(' H:i d-m-y ')); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Update at :</b> <a class="float-right"><?php echo e($permasalahan->updated_at->format(' H:i d-m-y ')); ?></a>
                  </li>
                </ul>
                <a href="<?php echo e(route('permasalahan.index')); ?>" class="btn btn-primary btn-block"><b>Kembali</b></a>
              </div>  
            </div>
          </div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bianca\Desktop\Projek\Skripsi2-master\resources\views/permasalahan/detail.blade.php ENDPATH**/ ?>