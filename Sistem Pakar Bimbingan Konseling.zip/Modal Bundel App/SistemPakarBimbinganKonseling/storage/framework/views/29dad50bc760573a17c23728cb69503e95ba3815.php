<div class="form-group">
	<ul class="alert alert-danger">
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($error); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
</div><?php /**PATH C:\Users\Bianca\Desktop\Projek\Skripsi2-master\resources\views/layouts/error.blade.php ENDPATH**/ ?>