<?php $__env->startSection('content'); ?>
  <section class="content">
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Data Basis Pengetahuan</h3>
      </div>
          <li class="nav-item d-none d-sm-inline-block">
            <a href="<?php echo e(route('permasalahan.create')); ?>" class="nav-link">Tambah Data</a>
          </li>
            <?php if(session('status')): ?>
              <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>  
              </div>
            <?php endif; ?>
        <div class="card-body p-0">
          <table class="table table-striped projects">
              <thead>
                  <tr>
                      <th style="width: 1%"> No </th>
                      <th style="width: 15%"> Keterangan Permasalahan  </th>
                      <th style="width: 20%"> Keterangan Gejala  </th>
                      <th style="width: 20%"> Keterangan Solusi  </th>
                      <th style="width: 10%" > Aksi </th>
                  </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $permasalahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($loop->iteration); ?>.</td>
                    <td><?php echo e($p->keteranganPermasalahan); ?></td>
                    <td>
                      <ul style="padding-left: 16px;">
                        <?php $__empty_1 = true; $__currentLoopData = $p->gejala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                          <li><?php echo e($g->keteranganGejala); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          Maaf, belum ada data gejala untuk Permasalahan ini.
                        <?php endif; ?>
                      </ul>
                    </td>
                    <td><?php echo e($p->solusi); ?></td>
                    <td class="project-actions text-right">
                      <a class="btn btn-warning btn-sm" href=" <?php echo e(route('permasalahan.edit', $p->id)); ?> ">
                         Edit
                      </a>
                        <form action="<?php echo e(route('permasalahan.destroy',$p->id)); ?>" method="post" style="display: inline-block;">
                          <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                              <input type="submit" name="" value="Delete" class="btn btn-danger btn-sm">
                        </form>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>
        </div>
      <div class="pagination justify-content-center" style="margin:20px 0">
        <?php echo e($relasi->links()); ?>

      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\SistemPakarBimbinganKonseling\resources\views/relasi/index.blade.php ENDPATH**/ ?>