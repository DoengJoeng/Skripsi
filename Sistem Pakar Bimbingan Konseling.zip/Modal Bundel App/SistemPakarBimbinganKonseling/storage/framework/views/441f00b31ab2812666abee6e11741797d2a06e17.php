<?php $__env->startSection('content'); ?>
  <section class="content">
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Data Bimbingan</h3>
      </div>
          <li class="nav-item d-none d-sm-inline-block">
            <a href="<?php echo e(route('bimbingan.create')); ?>" class="nav-link">Tambah Data</a>
          </li>
        <?php $__env->startSection('notifGejala'); ?>
          <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
              <?php echo e(session('status')); ?>  
            </div>
          <?php endif; ?>
        <?php $__env->stopSection(); ?>
        <div class="card-body p-0">
          <table class="table table-striped projects">
              <thead>
                  <tr>
                      <th style="width: 1%"> NO </th>
                      <th style="width: 10%"> Nama Lengkap </th>
                      <th style="width: 5%"> NIM </th>
                      <th style="width: 5%"> Jenis Kelamin </th>
                      <th style="width: 7%"> Aksi </th>
                  </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $bimbingan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td> <?php echo e($loop->iteration); ?> </td>
                    <td> <?php echo e($b->namaLengkap); ?> </td>
                    <td> <?php echo e($b->nim); ?></td>
                    <td> <?php echo e($b->jenisKelamin); ?></td>
                    <td class="project-actions text-right">
                      <a class="btn btn-info btn-sm" href="<?php echo e(route('bimbingan.show', $b->id)); ?>"> View </a>
                      <a class="btn btn-warning btn-sm" href="<?php echo e(route('bimbingan.edit', $b->id)); ?>">
                         Edit
                      </a>
                      <a class="btn btn-danger btn-sm" href="#">
                         Delete
                      </a>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>
        </div>
      <div class="pagination justify-content-center" style="margin:20px 0">
        <?php echo e($bimbingan->links()); ?>

      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\SistemPakarBimbinganKonseling\resources\views/bimbingan/index.blade.php ENDPATH**/ ?>