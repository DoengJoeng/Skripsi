<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="card mt-5">
      <div class="card-header text-left">
        <strong>Tambah Data Bimbingan</strong>
      </div>
      <div class="card-body">
        <form method="POST" action="<?php echo e(route('bimbingan.update',[$bimbingan->id])); ?>">
          <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
              <label for="nim"><strong> NIM </strong></label>
                <input type="text" name="nim" value="<?php echo e($bimbingan->nim); ?>" placeholder="Masukkan NIM anda " class="form-control  <?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  id="nim" >
                    <?php $__errorArgs = ['nim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="invalid-feedback">
                        <?php echo e($message); ?>

                      </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
              <label for="namaLengkap"><strong> Nama  Lengkap </strong></label>
                <input type="text" name="namaLengkap" value="<?php echo e($bimbingan->namaLengkap); ?>" placeholder="Masukkan Nama Lengkap anda "  class="form-control <?php $__errorArgs = ['namaLengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  id="namaLengkap" >
                  <?php $__errorArgs = ['namaLengkap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                      <?php echo e($message); ?>

                    </div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
              <label for="exampleFormControlSelect1"><strong>  Jenis Kelamin </strong></label>
                <select type="text" name="jenisKelamin" class="form-control" id="exampleFormControlSelect1">
                  <option value="Laki-Laki" >Laki-Laki</option>
                  <option value="Perempuan" >Perempuan</option>
                </select>
            </div>
            <div class="form-group">
              <label for="exampleFormControlSelect1"><strong> Status Tempat Tinggal </strong></label>
                <select type="text" name="status" class="form-control" id="exampleFormControlSelect1">
                  <option value="Outside" <?php if($bimbingan->status =="Outside"): ?> selected <?php endif; ?>>Outside</option>
                  <option value="Inside" <?php if($bimbingan->status =="Inside"): ?> selected <?php endif; ?> >Inside</option>
                </select>
            </div>                      
            <div class="form-group">
              <input type="submit" class="btn btn-success" value="Simpan">
          </div>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bianca\Desktop\Projek\Skripsi2-master\resources\views/bimbingan/edit.blade.php ENDPATH**/ ?>