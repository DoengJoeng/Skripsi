<?php $__env->startSection('content'); ?>
 <div class="container">
    <div class="card mt-5">
              <?php if(session('status')): ?>
          <div class="alert alert-success" role="alert">
            <?php echo e(session('status')); ?>  
          </div>
        <?php endif; ?>
      <div class="card-header text-left">
        <strong>Pilih Gejala-Permasalahan </strong>
      </div>
        <?php if($errors->all()): ?>
          <?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
      <div class="card-body">
        <form method="POST" action="<?php echo e(route('konselling.store')); ?>">
                <?php echo csrf_field(); ?>
              <input type="hidden" name="bimbingan_id" value="<?php echo e($bimbingan_id); ?>">
                <div class="form-group">
                    <label>Gejala-gejala yang nampak pada Sosial anda :</label>
                    <div class="col-md-12">
                        <?php $__currentLoopData = $gejala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gejala): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="checkbox">
                                <label><input class="flat" type="checkbox" name="gejala[]" value="<?php echo e($gejala->id); ?>">  <?php echo e($gejala->keteranganGejala); ?> </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary pull-right">Cek Hasil Konselling <i class="fa fa-fw fa-search"></i></button>
                </div>
            </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bianca\Desktop\Projek\Skripsi2-master\resources\views/konselling/create.blade.php ENDPATH**/ ?>