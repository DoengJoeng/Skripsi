<?php $__env->startSection('content'); ?>

   <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col">

    <!-- Profile Image -->
            <div class="card card-primary card-outline">
              <div class="card-body box-profile">
                <div class="text-center"><p><strong>Detail Data Bimbingan</strong></p>
                </div>

                <ul class="list-group list-group-unbordered mb-3">
                  <li class="list-group-item">
                    <b> NIM </b> <a class="float-right"><?php echo e($bimbingan->nim); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b> Nama Lengkap </b> <a class="float-right"><?php echo e($bimbingan->namaLengkap); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b> Status </b> <a class="float-right"><?php echo e($bimbingan->status); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b> jenisKelamin </b> <a class="float-right"><?php echo e($bimbingan->jenisKelamin); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Created at :</b> <a class="float-right"><?php echo e($bimbingan->created_at->format(' H:i d-m-y ')); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Update at :</b> <a class="float-right"><?php echo e($bimbingan->updated_at->format(' H:i d-m-y ')); ?></a>
                  </li>
                </ul>
                <fieldset class="border p-4">
                  <legend class="w-auto">Gejala</legend>
                  <ul>
                    <?php $__currentLoopData = $bimbingan->gejala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($item->keteranganGejala); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </fieldset>
                <hr>
                <fieldset class="border p-4">
                  <legend class="w-auto">Permasalahan</legend>
                  <?php if(count($permasalahan) > 0): ?>                    
                    <table class="table table-striped projects">
                      <thead>
                          <tr>
                              <th style="width: 1%"> No </th>
                              <th style="width: 15%"> Keterangan Permasalahan  </th>
                              <th style="width: 20%"> Keterangan Gejala  </th>
                              <th style="width: 20%"> Keterangan Solusi  </th>
                          </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $permasalahan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($loop->iteration); ?>.</td>
                            <td><?php echo e($p->keteranganPermasalahan); ?></td>
                            <td>
                              <ul style="padding-left: 16px;">
                                <?php $__empty_1 = true; $__currentLoopData = $p->gejala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                  <li><?php echo e($g->keteranganGejala); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                  Maaf, belum ada data gejala untuk Permasalahan ini.
                                <?php endif; ?>
                              </ul>
                            </td>
                            <td><?php echo e($p->solusi); ?></td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>    
                  <?php else: ?>
                    <div class="alert alert-danger">
                      Gejala Tidak di Temukan
                    </div>
                  <?php endif; ?>
                </fieldset>
                <hr>
                <a href="<?php echo e(route('bimbingan.index')); ?>" class="btn btn-primary btn-block"><b>Kembali</b></a>
              </div>  
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Bianca\Desktop\Projek\Skripsi2-master\resources\views/bimbingan/detail.blade.php ENDPATH**/ ?>