<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GejalaPermasalahan extends Model
{
    protected $table = 'gejalaPermasalahan';
    protected $fillable = ['permasalahan_id', 'gejala_id'];
}
