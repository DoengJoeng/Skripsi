<?php

namespace App\Models;
use App\Models\Relasi;
use App\Models\Gejala;
use Illuminate\Database\Eloquent\Model;

class Bimbingan extends Model
{
    protected $table = 'bimbingan';
    protected $fillable = ['nim', 'namaLengkap', 'status', 'jenisKelamin'];
    protected $guarded = [];

    
    // public function rules()
    // {
    // 	return $this->belongsTo(Relasi::class);
    // }

    public function gejala()
    {
    	return $this->belongsToMany(Gejala::class, 'tmpgejala');
    }    

    public function permasalahan()
    {
    	return $this->belongsToMany(Permasalahan::class, 'tmp_konselling');
    }    

    public function attachGejala($gejala_id)
    {
        $gejala = Gejala::find($gejala_id);
        return $this->gejala()->attach($gejala);
    }
}
