-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2020 at 06:37 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sistempakar`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_super` tinyint(1) NOT NULL DEFAULT 0,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `namaLengkap` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gambar` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenisKelamin` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `noHandphone` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bimbingan`
--

CREATE TABLE `bimbingan` (
  `id` int(10) UNSIGNED NOT NULL,
  `nim` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `namaLengkap` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `jenisKelamin` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bimbingan`
--

INSERT INTO `bimbingan` (`id`, `nim`, `namaLengkap`, `status`, `jenisKelamin`, `created_at`, `updated_at`) VALUES
(1, '1234567', 'Test', 'Outside', 'Laki-Laki', '2020-07-01 00:02:28', '2020-07-01 00:02:28'),
(2, '1681024', 'Test Nama', 'Inside', 'Perempuan', '2020-07-05 06:16:13', '2020-07-05 06:16:13'),
(3, '1681024', 'Hasudungan', 'Outside', 'Laki-Laki', '2020-07-05 23:39:41', '2020-07-05 23:39:41'),
(4, '1681024', 'Hasudungan', 'Outside', 'Laki-Laki', '2020-07-09 02:23:07', '2020-07-09 02:23:07'),
(5, '1681024', 'Junjung Hasudungan', 'Outside', 'Perempuan', '2020-07-09 02:30:29', '2020-07-09 02:30:29'),
(6, '1681024', 'Hasudungan', 'Outside', 'Laki-Laki', '2020-07-11 07:35:03', '2020-07-11 07:35:03'),
(7, '1681024', 'Hasudungan', 'Outside', 'Laki-Laki', '2020-07-11 07:41:56', '2020-07-11 07:41:56'),
(8, '1681024', 'Hasudungan', 'Outside', 'Laki-Laki', '2020-07-11 07:43:54', '2020-07-11 07:43:54'),
(9, '1234567', 'Rendi', 'Outside', 'Laki-Laki', '2020-07-11 08:04:02', '2020-07-11 08:04:02');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gejala`
--

CREATE TABLE `gejala` (
  `id` int(10) UNSIGNED NOT NULL,
  `kodeGejala` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keteranganGejala` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gejala`
--

INSERT INTO `gejala` (`id`, `kodeGejala`, `keteranganGejala`, `created_at`, `updated_at`) VALUES
(1, 'KG01', 'Berubah menjadi murung, mulai pendiam serta sering menyendiri.', '2020-06-30 00:27:52', '2020-07-05 23:31:00'),
(2, 'KG02', 'Kurang semangat dalam proses belajar', '2020-07-01 00:13:06', '2020-07-05 23:32:10'),
(3, 'KG04', 'Jarang masuk kekampus atau kelas', '2020-07-01 00:13:58', '2020-07-05 23:33:31'),
(4, 'KG04', 'Berkurang Fokus belajar ataupun bekerja', '2020-07-05 06:33:21', '2020-07-09 02:24:13'),
(5, 'KG05', 'Nilai IP atau GPA mulai turun.', '2020-07-05 21:41:20', '2020-07-09 02:25:36'),
(6, 'KG06', 'Bingung ,ragu dan sukar dalam memahami dan menyelesaikan pelajaran', '2020-07-05 21:41:58', '2020-07-09 02:26:14'),
(7, 'KG07', 'Belum memahami secara keseluruhan bidang kerja yang di minati', '2020-07-05 23:27:38', '2020-07-09 02:27:03'),
(8, 'KG08', 'Rasa amarah/benci/takut mudah meluap dan meningkat', '2020-07-09 02:28:37', '2020-07-09 02:28:37'),
(9, 'KG07', 'Belum memahami secara keseluruhan bidang kerja yang di minati', '2020-07-11 07:31:17', '2020-07-11 07:31:17'),
(10, 'KG09', 'Tidak Semangat lagi untuk melanjutkan perkuliahan', '2020-07-11 08:01:33', '2020-07-11 08:01:33');

-- --------------------------------------------------------

--
-- Table structure for table `gejalapermasalahan`
--

CREATE TABLE `gejalapermasalahan` (
  `permasalahan_id` int(10) UNSIGNED NOT NULL,
  `gejala_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gejalapermasalahan`
--

INSERT INTO `gejalapermasalahan` (`permasalahan_id`, `gejala_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2020-07-01 00:15:02', '2020-07-01 00:15:02'),
(1, 2, '2020-07-01 00:15:02', '2020-07-01 00:15:02'),
(1, 3, '2020-07-01 00:15:02', '2020-07-01 00:15:02'),
(2, 1, '2020-07-05 06:34:15', '2020-07-05 06:34:15'),
(2, 2, '2020-07-05 06:34:15', '2020-07-05 06:34:15'),
(2, 3, '2020-07-05 06:34:15', '2020-07-05 06:34:15'),
(2, 4, '2020-07-05 06:34:15', '2020-07-05 06:34:15'),
(7, 1, '2020-07-05 23:36:06', '2020-07-05 23:36:06'),
(7, 2, '2020-07-05 23:36:06', '2020-07-05 23:36:06'),
(7, 3, '2020-07-05 23:36:06', '2020-07-05 23:36:06'),
(8, 1, '2020-07-11 07:33:03', '2020-07-11 07:33:03'),
(8, 2, '2020-07-11 07:33:03', '2020-07-11 07:33:03'),
(8, 3, '2020-07-11 07:33:03', '2020-07-11 07:33:03'),
(8, 4, '2020-07-11 07:33:03', '2020-07-11 07:33:03'),
(8, 5, '2020-07-11 07:33:03', '2020-07-11 07:33:03'),
(8, 6, '2020-07-11 07:33:03', '2020-07-11 07:33:03'),
(9, 7, '2020-07-11 08:02:55', '2020-07-11 08:02:55'),
(9, 8, '2020-07-11 08:02:55', '2020-07-11 08:02:55'),
(9, 9, '2020-07-11 08:02:55', '2020-07-11 08:02:55'),
(9, 10, '2020-07-11 08:02:55', '2020-07-11 08:02:55');

-- --------------------------------------------------------

--
-- Table structure for table `konselling`
--

CREATE TABLE `konselling` (
  `id` int(10) UNSIGNED NOT NULL,
  `bimbingan_id` int(10) UNSIGNED NOT NULL,
  `permasalahan_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(34, '2020_04_21_082519_create_tasks_table', 1),
(98, '2020_04_27_105440_create_post_tags_table', 2),
(198, '2020_04_08_142343_create_bimbingan_table', 3),
(199, '2020_04_08_142726_create_admins_table', 3),
(200, '2020_04_08_143202_create_rules_table', 3),
(201, '2020_04_12_151910_create_gejala_table', 3),
(202, '2020_04_19_142951_create_register_table', 3),
(203, '2020_04_20_023338_create_login_table', 3),
(204, '2020_04_21_082642_create_employees_table', 3),
(205, '2020_04_27_085056_create_posts_posts_table', 3),
(206, '2020_04_27_085908_create_tags_table', 3),
(207, '2020_04_27_105441_create_post_tags_table', 3),
(208, '2020_04_28_073146_create_gejala_permasalahan_table', 3),
(209, '2020_04_28_082335_create_articles_table', 3),
(210, '2020_04_28_082425_create_categories_table', 3),
(211, '2020_05_07_092742_create_pesan_table', 3),
(212, '2020_05_08_070746_create_help_table', 3),
(214, '2020_05_15_013607_create_konselling_table', 4),
(216, '2020_05_17_095929_create_gejalas_table', 6),
(223, '2020_05_19_102346_create_solusi_table', 8),
(224, '2020_05_19_103427_create_bimbingan_table', 8),
(228, '2020_05_19_120914_create_rules_table', 10),
(240, '2020_05_26_110959_create_gejala_permasalahan_table', 12),
(275, '2020_05_19_151557_create_relasi_table', 13),
(278, '2020_05_26_190759_create_relasi_table', 14),
(311, '2014_10_12_100000_create_password_resets_table', 15),
(313, '2020_05_19_104913_create_gejala_table', 15),
(314, '2020_05_19_113551_create_solusi_table', 15),
(315, '2020_05_19_154936_create_bimbingan_table', 15),
(316, '2020_05_26_111239_create_konselling_table', 15),
(317, '2020_05_26_203437_create_relasi_table', 15),
(318, '2020_05_27_153845_create_permasalahan_table', 15),
(319, '2020_05_28_014823_create_test_table', 16),
(331, '2020_05_28_020231_create_relasi_table', 17),
(335, '2020_05_28_111139_create_relasi_table', 19),
(351, '2020_05_28_095140_create_relasi_permasalahan_gejala_table', 20),
(440, '2020_05_29_023429_create_base_pengetahuan_table', 21),
(457, '2020_05_28_020137_create_bimbingan_create', 22),
(461, '2020_05_29_093821_create_tmp_konselling_table', 22),
(589, '2020_06_22_060312_create_kode_permasalahan_table', 23),
(691, '2014_10_12_000000_create_users_table', 24),
(692, '2019_08_19_000000_create_failed_jobs_table', 24),
(693, '2020_05_28_015951_create_permasalahan_table', 24),
(694, '2020_05_28_020042_create_gejala_table', 24),
(695, '2020_05_28_020442_create_solusi_table', 24),
(696, '2020_05_30_085952_create_gejala_permasalahan_table', 24),
(697, '2020_06_02_022643_create_bimbingan_table', 24),
(698, '2020_06_02_022949_create_konselling_table', 24),
(699, '2020_06_02_032638_create_tmp_gejala_table', 24),
(700, '2020_06_25_133631_create_tmp_konselling_table', 24),
(701, '2020_07_10_025254_create_admin_table', 25);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permasalahan`
--

CREATE TABLE `permasalahan` (
  `id` int(10) UNSIGNED NOT NULL,
  `kodePermasalahan` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keteranganPermasalahan` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `solusi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permasalahan`
--

INSERT INTO `permasalahan` (`id`, `kodePermasalahan`, `keteranganPermasalahan`, `solusi`, `created_at`, `updated_at`) VALUES
(1, 'KP01', 'Keterangan Permasalahan 01', 'Keterangan Solusi 01', '2020-07-01 00:15:02', '2020-07-01 00:15:02'),
(2, 'KP03', 'Test Keterangan Permasalahan', 'Keterangan Solusi 02', '2020-07-05 06:34:15', '2020-07-05 06:34:15'),
(6, 'KP03', 'Test Keterangan Permasalahan', 'Keterangan Solusi 02', '2020-07-05 23:06:34', '2020-07-05 23:06:34'),
(7, 'KP04', 'Keluarga', 'Beri dukungan, perhatian serta doa setiap waktu kepada teman/orang tua,', '2020-07-05 23:36:06', '2020-07-05 23:36:06'),
(8, 'KP05', 'Diri Pribadi', 'Pertambah hubungan sosial dengan orang yang dapat membantu masalah anda', '2020-07-11 07:33:03', '2020-07-11 07:33:03'),
(9, 'KP10', 'Bullying', 'Melakukan self-talk atau dapat dikatakan berbicara dengan diri sendiri yang berguna untuk meng observasi kelemahan dan kelebihan dalam diri.', '2020-07-11 08:02:55', '2020-07-11 08:02:55');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `fullname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `repassword` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `solusi`
--

CREATE TABLE `solusi` (
  `id` int(10) UNSIGNED NOT NULL,
  `kodeSolusi` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keteranganSolusi` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `permasalahan_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tmpgejala`
--

CREATE TABLE `tmpgejala` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `bimbingan_id` int(10) UNSIGNED NOT NULL,
  `gejala_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tmp_konselling`
--

CREATE TABLE `tmp_konselling` (
  `bimbingan_id` int(10) UNSIGNED DEFAULT NULL,
  `permasalahan_id` int(10) UNSIGNED DEFAULT NULL,
  `gejala` int(10) UNSIGNED DEFAULT NULL,
  `gejala_terpenuhi` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'hasudungan', 'Hasudungan03@gmail.com', NULL, '$2y$10$pUgZAwTPW0oWwZ5GGal.jOujSiRDIHAVlkHbhSYwHv227Havw9tZG', NULL, '2020-06-30 23:18:43', '2020-06-30 23:18:43'),
(2, 'Hasudungan', 'Hasudungan06@gmail.com', NULL, '$2y$10$Awq3Jy.SXPraINLpYeh/v.VCFcJ4tFhzAqxqHhq0sCqnt39OfZnhq', NULL, '2020-07-05 06:38:16', '2020-07-05 06:38:16'),
(3, 'Test', 'Test@gmail.com', NULL, '$2y$10$5lNQkQr3B5sfqv1uwQGMve5kdoXIsvZpkSkOvpqMuXDQe.UAy08NW', NULL, '2020-07-05 23:25:08', '2020-07-05 23:25:08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admin_email_unique` (`email`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bimbingan`
--
ALTER TABLE `bimbingan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gejala`
--
ALTER TABLE `gejala`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gejalapermasalahan`
--
ALTER TABLE `gejalapermasalahan`
  ADD KEY `gejalapermasalahan_permasalahan_id_foreign` (`permasalahan_id`),
  ADD KEY `gejalapermasalahan_gejala_id_foreign` (`gejala_id`);

--
-- Indexes for table `konselling`
--
ALTER TABLE `konselling`
  ADD PRIMARY KEY (`id`),
  ADD KEY `konselling_bimbingan_id_foreign` (`bimbingan_id`),
  ADD KEY `konselling_permasalahan_id_foreign` (`permasalahan_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `permasalahan`
--
ALTER TABLE `permasalahan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `solusi`
--
ALTER TABLE `solusi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tmpgejala`
--
ALTER TABLE `tmpgejala`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tmpgejala_bimbingan_id_foreign` (`bimbingan_id`),
  ADD KEY `tmpgejala_gejala_id_foreign` (`gejala_id`);

--
-- Indexes for table `tmp_konselling`
--
ALTER TABLE `tmp_konselling`
  ADD KEY `tmp_konselling_bimbingan_id_foreign` (`bimbingan_id`),
  ADD KEY `tmp_konselling_permasalahan_id_foreign` (`permasalahan_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bimbingan`
--
ALTER TABLE `bimbingan`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gejala`
--
ALTER TABLE `gejala`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `konselling`
--
ALTER TABLE `konselling`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=702;

--
-- AUTO_INCREMENT for table `permasalahan`
--
ALTER TABLE `permasalahan`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `solusi`
--
ALTER TABLE `solusi`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tmpgejala`
--
ALTER TABLE `tmpgejala`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `gejalapermasalahan`
--
ALTER TABLE `gejalapermasalahan`
  ADD CONSTRAINT `gejalapermasalahan_gejala_id_foreign` FOREIGN KEY (`gejala_id`) REFERENCES `gejala` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `gejalapermasalahan_permasalahan_id_foreign` FOREIGN KEY (`permasalahan_id`) REFERENCES `permasalahan` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `konselling`
--
ALTER TABLE `konselling`
  ADD CONSTRAINT `konselling_bimbingan_id_foreign` FOREIGN KEY (`bimbingan_id`) REFERENCES `bimbingan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `konselling_permasalahan_id_foreign` FOREIGN KEY (`permasalahan_id`) REFERENCES `permasalahan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tmpgejala`
--
ALTER TABLE `tmpgejala`
  ADD CONSTRAINT `tmpgejala_bimbingan_id_foreign` FOREIGN KEY (`bimbingan_id`) REFERENCES `bimbingan` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tmpgejala_gejala_id_foreign` FOREIGN KEY (`gejala_id`) REFERENCES `gejala` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `tmp_konselling`
--
ALTER TABLE `tmp_konselling`
  ADD CONSTRAINT `tmp_konselling_bimbingan_id_foreign` FOREIGN KEY (`bimbingan_id`) REFERENCES `bimbingan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tmp_konselling_permasalahan_id_foreign` FOREIGN KEY (`permasalahan_id`) REFERENCES `permasalahan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
